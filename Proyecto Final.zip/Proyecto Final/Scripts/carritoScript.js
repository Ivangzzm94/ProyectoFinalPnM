$(document).ready(function(){
	carrito();
});

function carrito()
{
	$.ajax({
		url: 'data/sessionService.php',
		type: 'GET',
		dataType: 'json',
		success: function(exito)
		{
			sesion();
		},
		error: function(errorMs)
		{
			alert(errorMs.responseText);
		}
	});
}

function sesion()
{
	$.ajax({
		url: 'data/carritoAdquisicion.php',
		type: 'GET',
		dataType: 'json',
		success: function(carrito)
		{
			adquisicionCarrito(carrito);
		},
		error: function(errorMsg)
		{
			alert(errorMsg.responseText);
		}
	});
}

function adquisicionCarrito(carrito)
{
	if(carrito.length > 0)
	{
		for(var i=0; i < carrito.length; i++)
		{
			$tipoArticulo = carrito[i].tipoArticulo;
			$idArticulo = carrito[i].idArticulo;
			$cantidad = carrito[i].cantidad;
			$max = carrito.length;
			$vuelta = i;

			var jsonToSend = {
								"tipoArticulo" : $tipoArticulo,
								"idArticulo" : $idArticulo,
								"cantidad" : $cantidad,
								"max" : $max,
								"vuelta" : $vuelta
							 };

			inventario(jsonToSend);
		}

		auxiliar = "<div><button>Comprar</button></div>";
		$("#carritoActual").append(auxiliar);

		$('div > button').on("click",function(){
			comprar();
			$("#carritoActual").children().hide();
		});
	}
}

function inventario(jsonToSend)
{
	$.ajax({
		url: 'data/inventario.php',
		type: 'POST',
		dataType: 'json',
		data: jsonToSend,
		contentType: "application/x-www-form-urlencoded",
		success: function(articulo)
		{
			$tipo = articulo.tipo;
			$cantidad = articulo.cantidad;
			$max = articulo.max;
			$vuelta = parseInt(articulo.vuelta)+1;
			$id = articulo.id;
			
			if($tipo === 'Gorra')
			{
				auxiliar = "<p><img src='" + articulo.articulo.urlGorra + "'><br>";
				auxiliar += "Nombre: " + articulo.articulo.nombreGorra + "<br>";
				auxiliar += "Precio: " + articulo.articulo.precioGorra + "<br>";
				auxiliar += "Cantidad: " + $cantidad+"<br>";
				auxiliar += "<button id='"+$id+"'>Cancelar</button>";
				$("#carritoActual").append(auxiliar);
			}
			else
			{
				if($tipo === 'Playera')
				{
					auxiliar = "<p><img src='" + articulo.articulo.urlPlayera + "'><br>";
					auxiliar += "Nombre: " + articulo.articulo.nombrePlayera + "<br>";
					auxiliar += "Precio: " + articulo.articulo.precioPlayera + "<br>";
					auxiliar += "Cantidad: " + $cantidad +"<br>";
					auxiliar += "<button id='"+ $id +"'>Cancelar</button>";
					$("#carritoActual").append(auxiliar);
				}
				else
				{
					auxiliar = "<p><img src='" + articulo.articulo.urlSudadera + "'><br>";
					auxiliar += "Nombre: " + articulo.articulo.nombreSudadera + "<br>";
					auxiliar += "Precio: " + articulo.articulo.precioSudadera + "<br>";
					auxiliar += "Cantidad: " + $cantidad +"<br>";
					auxiliar += "<button id='"+ $id +"'>Cancelar</button>";
					$("#carritoActual").append(auxiliar);
				}
			}
			
			if($vuelta == $max)
			{

				$('p > button').on("click", function(){
					cancelar($(this).attr('id'));
					$(this).parent().hide();
				});
			}
		},
		error: function(error)
		{
			alert(errorMsg.responseText);
		}
	});
}

function comprar(){
	$.ajax({
		url: 'data/compra.php',
		type: 'GET',
		dataType: 'json',
		success: function(compra)
		{
			alert(compra);
		},
		error: function(error)
		{

		}
	});
}

function cancelar($id)
{
	var jsonNew={'id' : $id};	

	$.ajax({
		url: 'data/cancelarCarrito.php',
		dataType: 'json',
		type: 'POST',
		contentType: "application/x-www-form-urlencoded",
		data: jsonNew,
		success: function(cancelar)
		{
			alert(cancelar);
		},
		error: function(error_msg)
		{

		}
	});
}