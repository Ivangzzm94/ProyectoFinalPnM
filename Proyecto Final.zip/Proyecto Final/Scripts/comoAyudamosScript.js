$(document).ready(function(){
	menuFunctionality();
});

function menuFunctionality()
{
	$(".currentSelection .hiddenSection").slideUp(10).removeClass("hiddenSection");
	$(".currentSelection").slideDown(10);
	$("#menu > li").on("click",function()
	{
		$(".currentSelection").slideUp(200).removeClass(".currentSelection");
		$(".selected").removeClass("selected");

		var currentSection = $(this).attr("class");
		$("#" + currentSection).addClass("currentSelection");
		$("#" + currentSection).delay(200).slideDown(200);
		$(this).addClass("selected");
	});
}