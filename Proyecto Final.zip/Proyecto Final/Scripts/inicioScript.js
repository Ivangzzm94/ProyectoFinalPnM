$(document).ready(function(){
		agregarNovedades();
		$("#ir").on("click", buscador);
		$("#regresar").on("click", regresar);
	});

	function regresar()
	{
		window.location.replace("Inicio.html");
	}

	function buscador()
	{
		var jsonToSend = {"dato": $("#buscador").val()};

			$.ajax({
			url: 'data/buscador.php',
			type: 'POST',
			dataType: 'json',
			data: jsonToSend,
			contentType : "application/x-www-form-urlencoded",
			success: function(busqueda)
			{
				var auxiliar;
				if ($("#tipo").val() == "gorras")
				{
					$("p").empty();
					if (busqueda[0].nombreGorra != null)
					{
						auxiliar = "<p><img src='" + busqueda[0].urlGorra + "'><br>";
						auxiliar += "Nombre: " + busqueda[0].nombreGorra + "<br>";
						auxiliar += "Precio: " + busqueda[0].precioGorra + "<br>";
						auxiliar += "Cantidad: <input type='text'><br>";
						auxiliar += "<button>Agregar a Carrito</button><br></p>";
						$("#novedades").append(auxiliar);
					}
					else{
						$("p").empty();
						alert("No se encontro una gorra con ese nombre!");
					}
				}
				else
					if ($("#tipo").val() == "playeras")
					{
						if (busqueda[0].nombrePlayera != null)
						{
							$("p").empty();
							auxiliar = "<p><img src='" + busqueda[0].urlPlayera + "'><br>";
							auxiliar += "Nombre: " + busqueda[0].nombrePlayera + "<br>";
							auxiliar += "Precio: " + busqueda[0].precioPlayera + "<br>";
							auxiliar += "Cantidad: <input type='text'><br>";
							auxiliar += "<button>Agregar a Carrito</button><br></p>";
							$("#novedades").append(auxiliar);
						}
						else{
						$("p").empty();
						alert("No se encontro una playera con ese nombre!");
						}
					}
					else
					{
						if (busqueda[0].nombreSudadera != null)
						{
							$("p").empty();
							auxiliar = "<p><img src='" + busqueda[0].urlSudadera + "'><br>";
							auxiliar += "Nombre: " + busqueda[0].nombreSudadera + "<br>";
							auxiliar += "Precio: " + busqueda[0].precioSudadera + "<br>";
							auxiliar += "Cantidad: <input type='text'><br>";
							auxiliar += "<button>Agregar a Carrito</button><br></p>";
							$("#novedades").append(auxiliar);
						}
						else{
						$("p").empty();
						alert("No se encontro una sudadera con ese nombre!");
						}
					}
			},
			error: function(errorMsg)
			{
				if($("#buscador").val() != "")
				{
					$("p").empty();
					alert("No se encontro ningun producto con el nombre: " + $("#buscador").val());
				}
				else
				{
					$("p").empty();
					alert("No ingreso texto para buscar");
				}
			}
		});
	}


	function agregarNovedades()
	{
		$.ajax({
			url: 'data/novedades.php',
			type: 'GET',
			dataType: 'json',
			success: function(novedades)
			{
				var limite = novedades.gorra.length - 3;
				var aux = novedades.gorra.length;
				var auxiliar;
				for(var i = aux; i > limite; i--)
				{
					auxiliar = "<p><img src='" + novedades.gorra[i-1].urlGorra + "'id='"+ novedades.gorra[i-1].idGorra+"'><br>";
					auxiliar += "Nombre: " + novedades.gorra[i-1].nombreGorra + "<br>";
					auxiliar += "Precio: " + novedades.gorra[i-1].precioGorra + "<br>";
					auxiliar += "Cantidad: <input type='text'><br>";
					auxiliar += "<button>Agregar a Carrito</button><br></p>";

					$("#novedades").append(auxiliar);
				} 

				var limite = novedades.playera.length - 3;
				var aux = novedades.playera.length;
				var auxiliar;
				for(var i = aux; i > limite; i--)
				{
					auxiliar = "<p><img src='" + novedades.playera[i-1].urlPlayera + "'id='"+ novedades.playera[i-1].idPlayera+"'><br>";
					auxiliar += "Nombre: " + novedades.playera[i-1].nombrePlayera + "<br>";
					auxiliar += "Precio: " + novedades.playera[i-1].precioPlayera + "<br>";
					auxiliar += "Cantidad: <input type='text'><br>";
					auxiliar += "<button>Agregar a Carrito</button><br></p>";

					$("#novedades").append(auxiliar);
				} 

				var limite = novedades.sudadera.length - 3;
				var aux = novedades.sudadera.length;
				var auxiliar;
				for(var i = aux; i > limite; i--)
				{
					auxiliar = "<p><img src='" + novedades.sudadera[i-1].urlSudadera + "'id='"+ novedades.sudadera[i-1].idSudadera+"'><br>";
					auxiliar += "Nombre: " + novedades.sudadera[i-1].nombreSudadera + "<br>";
					auxiliar += "Precio: " + novedades.sudadera[i-1].precioSudadera + "<br>";
					auxiliar += "Cantidad: <input type='text'><br>";
					auxiliar += "<button>Agregar a Carrito</button><br></p>";

					$("#novedades").append(auxiliar);
				} 


				$("button").on("click",function(){
					$id = $(this).parent().find('img').attr('id');
					$cantidad = $(this).parent().find('input[type=text]').val();
					
					$.ajax({
						url: 'data/sessionService.php',
						type: 'GET',
						dataType: 'json',
						success: function(exito)
						{
							
							if($id[1] == 'g')
							{
								$tipoArticulo = 'Gorra';
							}
							else 
							{
								if($id[1] == 'p')
								{
									$tipoArticulo = 'Playera';
								}
								else
								{
									$tipoArticulo = 'Sudadera';
								}
							}

							var jsonToSend = {
												"IDarticulo" : $id,
												"tipoArticulo" : $tipoArticulo,
												"cantidad" : $cantidad
											 };

							$.ajax({
								url: 'data/carritoEntregar.php',
								type: 'POST',
								dataType: 'json',
								data: jsonToSend,
								contentType: "application/x-www-form-urlencoded",
								success: function(carrito)
								{
									alert(carrito);
								},
								error: function(errorMessage)
								{
									alert(errorMessage.responseText);
								}
								
							});
						},
						error: function(errorMs)
						{
							alert(errorMs.responseText);
						}
					});
				});
			},
			error: function(errorMsg)
			{
				alert(errorMsg.responseText);
			}
		});
	}