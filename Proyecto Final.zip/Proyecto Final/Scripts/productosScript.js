$(document).ready(function(){
	cargarGorras();
	cargarPlayeras();
	cargarSudaderas();

	$("#gorras").on("click",gorraShow);
	$("#playeras").on("click",playeraShow);
	$("#sudaderas").on("click",sudaderaShow);

});

function cargarGorras()
{
	$.ajax({
		url: 'data/inventarioGorras.php',
		type: 'GET',
		dataType: 'json',
		success: function(productos)
		{
			for(var i = 0; i < productos.length; i++)
			{
				var auxiliar = "<p><img src='" + productos[i].urlGorra + "'id='"+productos[i].idGorra+"'><br>";
				auxiliar += "Nombre: " + productos[i].nombreGorra + "<br>";
				auxiliar += "Precio: " + productos[i].precioGorra + "<br>";
				auxiliar += "Cantidad: <input type='text'><br>";
				auxiliar += "<button>Agregar a Carrito</button><br></p>";
				$("#imgGorras").append(auxiliar);
			}

		},
		error: function(errorMsg)
		{
			alert(errorMsg.statusText);
		}
	});
}
function cargarPlayeras()
{

	$.ajax({
		url: 'data/inventarioPlayeras.php',
		type: 'GET',
		dataType: 'json',
		success: function(productos)
		{
			for(var i = 0; i < productos.length; i++)
			{
				var auxiliar = "<p><img src='" + productos[i].urlPlayera+ "'id='"+productos[i].idPlayera+"'><br>";
				auxiliar += "Nombre: " + productos[i].nombrePlayera + "<br>";
				auxiliar += "Precio: " + productos[i].precioPlayera + "<br>";
				auxiliar += "Cantidad: <input type='text'><br>";
				auxiliar += "<button>Agregar a Carrito</button><br></p>";
				$("#imgPlayeras").append(auxiliar);
			}
		},
		error: function(errorMsg)
		{
			alert(errorMsg.responseText);
		}
	});
}
function cargarSudaderas()
{
	$.ajax({
		url: 'data/inventarioSudaderas.php',
		type: 'GET',
		dataType: 'json',
		success: function(productos)
		{
			
			for(var i = 0; i < productos.length; i++)
			{
				var auxiliar = "<p><img src='" + productos[i].urlSudadera+ "'id='"+productos[i].idSudadera+"'><br>";
				auxiliar += "Nombre: " + productos[i].nombreSudadera + "<br>";
				auxiliar += "Precio: " + productos[i].precioSudadera + "<br>";
				auxiliar += "Cantidad: <input type='text'><br>"; 
				auxiliar += "<button>Agregar a Carrito</button><br></p>";
				$("#imgSudaderas").append(auxiliar);
			}
			
			
			$("button").on("click",function(){
				$id = $(this).parent().find('img').attr('id');
				$cantidad = $(this).parent().find('input[type=text]').val();
				$.ajax({
					url: 'data/sessionService.php',
					type: 'GET',
					dataType: 'json',
					success: function(exito)
					{

						if($id[1] == 'g')
						{
							$tipoArticulo = 'Gorra';
						}
						else 
						{
							if($id[1] == 'p')
							{
								$tipoArticulo = 'Playera';
							}
							else
							{
								$tipoArticulo = 'Sudadera';
							}
						}

						var jsonToSend = {
											"IDarticulo" : $id,
											"tipoArticulo" : $tipoArticulo,
											"cantidad" : $cantidad
										 };

						$.ajax({
							url: 'data/carritoEntregar.php',
							type: 'POST',
							dataType: 'json',
							data: jsonToSend,
							contentType: "application/x-www-form-urlencoded",
							success: function(carrito)
							{
								alert(carrito);
							},
							error: function(errorMessage)
							{
								alert(errorMessage.responseText);
							}
							
						});
					},
					error: function(errorMs)
					{
						alert(errorMs.responseText);
					}
				});
			});
		},
		error: function(errorMsg)
		{
			alert(errorMsg.responseText);
		}
	});
}

function gorraShow()
{
	$("#imgGorras").show();
	$("#imgPlayeras").hide();
	$("#imgSudaderas").hide();
}

function playeraShow()
{
	$("#imgGorras").hide();
	$("#imgPlayeras").show();
	$("#imgSudaderas").hide();
}

function sudaderaShow()
{
	$("#imgGorras").hide();
	$("#imgPlayeras").hide();
	$("#imgSudaderas").show();
}