$(document).ready(function(){
	cookie();
	$("#login").on("click", login);
	$("#logout").on("click", logout);
});

function login()
{ 
	$rememberme = $("#cookie").is(":checked");
	var loginToSend = {
						"usName" : $("#usuario").val(),
						"usPwrd" : $("#password").val(),
						"remember" : $rememberme
					 };

	$.ajax({
		url: "data/loginService.php",
		type: "POST",
		data: loginToSend,
		dataType: "json",
		contentType: "application/x-www-form-urlencoded",
		success:function(jsonReceived){
			alert(jsonReceived);
			console.log(jsonReceived);
		},
		error: function(errorMsg){
			alert(errorMsg.responseText);
		}
	});
}

function logout()
{
	$.ajax({
		url: "data/deleteSession.php",
		type: "GET",
		dataType: "json",
		success: function(sessionJson){
			alert(sessionJson.successMessage);
		},
		error: function(errorMessage){
			alert(errorMessage.responseText);
		}
	});
}

function cookie()
{
	$.ajax({
		url: 'data/cookieService.php',
		dataType: 'json',
		type: 'GET',
		success: function(cookies)
		{
			$("#usuario").val(cookies.username);
		},
		error: function(errorMsg)
		{
		}
	});
}