$(document).ready(function(){
	
	$("#inicioSesion").on("click", inicioSesion);
	$("#inicio").on("click", inicio);
	$("#nosotros").on("click", nosotros);
	$("#productos").on("click", productos);
	$("#carrito").on("click", carrito);
	$("#contacto").on("click", contacto);
	$("#ayuda").on("click", ayuda);
	$("#noticias").on("click", noticias);
	
});

function inicio()
{
	window.location.replace("Inicio.html");
}

function nosotros()
{
	window.location.replace("Nosotros.html");
}

function productos()
{
	window.location.replace("NuestrosProductos.html");
}

function carrito()
{
	window.location.replace("Carrito.html");
}

function contacto()
{
	window.location.replace("Contacto.html");
}

function ayuda()
{
	window.location.replace("ComoAyudamos.html");
}

function noticias()
{
	window.location.replace("Noticias.html");
}

function inicioSesion()
{
	window.location.replace("InicioSesion.html");
}