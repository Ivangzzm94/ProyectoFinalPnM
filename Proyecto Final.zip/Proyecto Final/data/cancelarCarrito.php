<?php
	header('Content-type: application/json');
	header('Accept: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$conn = connectionToDataBase();

	if($conn == null)
	{
		header('HTTP/1.1 500 Bad connection to Database');
		die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		session_start();
		$idUsuario = $_SESSION['IDuser'];
		$idUsuario = $idUsuario['idUsuario'];

		$idArticulo = $_POST['id'];

		$sql = "DELETE FROM Carrito WHERE idArticulo = '$idArticulo' AND idCarrito = '$idUsuario'";

		$result = mysqli_query($conn, $sql);

		if($result)
		{
			echo json_encode("Se borro el articulo exitosamente");
		}
	}
?>