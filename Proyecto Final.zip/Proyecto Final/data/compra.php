<?php
	header('Content-type: application/json');
	header('Accept: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$conn = connectionToDataBase();
		
	
	if ($conn == null)
	{
		header('HTTP/1.1 500 Bad connection to Database');
		die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		session_start();
		$idUsuario = $_SESSION['IDuser'];
		
		$sql = "SELECT * FROM Carrito WHERE idCarrito = '$idUsuario'";

		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$id = $row['idCarrito'];
				$tipo = $row['tipoArticulo'];
				$idA = $row['idArticulo'];
				$cant = $row['cantidad'];

				$sql = "INSERT INTO Comprado(idComprado, tipoArticulo, idArticulo, cantidad) 
						VALUES('$id','$tipo','$idA','$cant')";

				$results = mysqli_query($conn, $sql);
				
				$sql = "DELETE FROM Carrito WHERE idCarrito = '$idUsuario'";

				$results = mysqli_query($conn, $sql);

			}

			echo json_encode("Compra exitosa");
		}
		else
		{
			die("Error al cargar la pagina");
		}
	}
?>