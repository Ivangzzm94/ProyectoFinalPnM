<?php
	
	function connectionToDataBase()
	{
		$servername = "localhost";
		$username = "root";
		$password = "root";
		$dbname = "pnm_bd";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		
		// Check connection
		if ($conn->connect_error) 
		{
			return null;
		}
		else
		{
			return $conn;
		}
	}

	function attemptLogin($userName, $userPassword)
	{
		
		$connection = connectionToDataBase();

		if ($connection != null)
		{
			$sql = "SELECT idUsuario FROM Usuario WHERE username='$userName' AND contrasena='$userPassword'";
		
			$result = mysqli_query($connection, $sql);
			
			if ($result->num_rows > 0)
			{
				$row = mysqli_fetch_assoc($result);
				
				session_start();
				$_SESSION['IDuser'] = $row['idUsuario'];

				$connection -> close();
				return true;
			}
			else
			{
				$connection -> close();
				return "406";
			}
		}
		else
		{
			return "500";
		}
	}


?>