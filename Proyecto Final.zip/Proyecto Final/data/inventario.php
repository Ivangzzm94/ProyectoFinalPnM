<?php
	header('Content-type: application/json');
	header('Accept: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$conn = connectionToDataBase();

	if($conn == null)
	{
		header('HTTP/1.1 500 Bad connection to Database');
		die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		$tipoArticulo = $_POST['tipoArticulo'];
		$idArticulo = $_POST['idArticulo'];
		$cantidad = $_POST['cantidad'];
		$max = $_POST['max'];
		$vuelta = $_POST['vuelta'];

		if($tipoArticulo == 'Gorra')
		{
			$sql = "SELECT * FROM Gorra WHERE idGorra = '$idArticulo'";

			$result = mysqli_query($conn, $sql);
		
			if($result->num_rows > 0)
			{
				$row = mysqli_fetch_assoc($result);
				 
				echo json_encode($results = array("tipo" => $tipoArticulo, "articulo" => $row, "cantidad" => $cantidad, "max" => $max, "vuelta" => $vuelta, "id" => $idArticulo));
			}
			else
			{
				die('Problemas al cargar la pagina');
			}
		}
		else
		{
			if($tipoArticulo == 'Playera')
			{
				$sql = "SELECT * FROM Playera WHERE idPlayera = '$idArticulo'";

				$result = mysqli_query($conn, $sql);

				if($result->num_rows > 0)
				{
					$row = mysqli_fetch_assoc($result);
				
					echo json_encode($results = array("tipo" => $tipoArticulo, "articulo" => $row, "cantidad" => $cantidad, "max" => $max, "vuelta" => $vuelta, "id" => $idArticulo));
				}
				else
				{
					die('Problemas al cargar la pagina');
				}
			}
			else
			{
				$sql = "SELECT * FROM Sudadera WHERE idSudadera = '$idArticulo'";

				$result = mysqli_query($conn, $sql);

				if($result->num_rows > 0)
				{
					$row = mysqli_fetch_assoc($result);
				
					echo json_encode($results = array("tipo" => $tipoArticulo, "articulo" => $row, "cantidad" => $cantidad, "max" => $max, "vuelta" => $vuelta, "id" => $idArticulo));
				}
				else
				{
					die('Problemas al cargar la pagina');
				}
			}
		}
	}
?>