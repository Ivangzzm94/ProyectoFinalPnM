<?php
	header('Content-type: application/json');
	header('Accept: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$conn = connectionToDataBase();
		
	
	if ($conn == null)
	{
		header('HTTP/1.1 500 Bad connection to Database');
		die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		session_start();
		$idUsuario = $_SESSION['IDuser'];
		
		$sql = "SELECT * FROM Carrito WHERE idCarrito = '$idUsuario'";

		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$results[] = $row;
			}
			echo json_encode($results);
		}
		else
		{
			die("No ha realizado ninguna compra.");
		}
	}
?>