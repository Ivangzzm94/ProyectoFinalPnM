<?php
	header('Accept: application/json');
	header('Content-type: application/json');
	require_once __DIR__ . '/dataLayer.php';

	
	$uName = $_POST["usName"]; //guarda en variable el valor de uName
	$uPassword = $_POST["usPwrd"];
	$remember = $_POST["remember"]; //guarda en $remeber el valor de la checkbox
	
	$comp = attemptLogin($uName, $uPassword);

	
	if($comp === true)
	{
		#Gurdar cookie
		if ($remember == true) 
		{
			setcookie("username", $uName, time() + 3600*24*20); //Crea la cookie
		}

		echo json_encode("¡Bienvenido!");
	}
	else
	{
		switch ($comp)
		{
			case "406" : header('HTTP/1.1 406 User not found');
						die("Usuario o contraseña incorrecto.");
						break;
			case "500" : header('HTTP/1.1 500 Bad connection to Database');
						die("The server is down, we couldn't establish the DB connection");
						break;
		}

	}
	
?>
