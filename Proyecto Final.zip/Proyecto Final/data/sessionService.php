<?php
	header('Content-type: application/json');

	session_start();
	if(isset($_SESSION["IDuser"])) //verifica que las variables tengan contenido diferente de null
	{
		echo json_encode(array("IDuser" => $_SESSION["IDuser"]));
	}
	else
	{
		header('HTTP/1.1 406 Session has expired.');
		die(" Registrese o inicie sesión");
	}
?>