CREATE TABLE Usuario(
  	idUsuario VARCHAR(5) NOT NULL,
		nombre VARCHAR(30) NOT NULL,
    apellido VARCHAR(30) NOT NULL,
    username VARCHAR(30) NOT NULL PRIMARY KEY,
    contrasena VARCHAR(30) NOT NULL
);

CREATE TABLE Carrito(
		idCarrito VARCHAR(5) NOT NULL,
		tipoArticulo VARCHAR(10) NOT NULL,
  	idArticulo VARCHAR(5) NOT NULL,
  	cantidad VARCHAR(5) NOT NULL  
);

CREATE TABLE Comprado(
  	idComprado VARCHAR(5) NOT NULL,
  	tipoArticulo VARCHAR(10) NOT NULL,
  	idArticulo VARCHAR(5) NOT NULL,
  	cantidad VARCHAR(5) NOT NULL
);

CREATE TABLE Gorra(
  	idGorra VARCHAR(5) NOT NULL PRIMARY KEY,
  	nombreGorra VARCHAR(30) NOT NULL,
  	urlGorra VARCHAR(100) NOT NULL,
    precioGorra VARCHAR(5) NOT NULL
);

CREATE TABLE Sudadera(
  	idSudadera VARCHAR(5) NOT NULL PRIMARY KEY,
  	nombreSudadera VARCHAR(30) NOT NULL,
  	urlSudadera VARCHAR(100) NOT NULL,
    precioSudadera VARCHAR(5) NOT NULL
);

CREATE TABLE Playera(
  	idPlayera VARCHAR(5) NOT NULL PRIMARY KEY,
  	nombrePlayera VARCHAR(30) NOT NULL,
  	urlPlayera VARCHAR(100) NOT NULL,
    precioPlayera VARCHAR(5) NOT NULL
);

INSERT INTO Usuario(idUsuario, nombre, apellido, username, contrasena)
VALUES  ('1', 'Alfredo', 'Salazar', 'alfredo08', 'alfred90'),
    ('2', 'Pamela', 'Rodriguez', 'thePam22', '22mapeht');

INSERT INTO Gorra(idGorra, nombreGorra, urlGorra, precioGorra)
VALUES  ('1g','gorra1','Imagenes/Gorras/gorra1.jpg','100'),
        ('2g','gorra2','Imagenes/Gorras/gorra2.jpg','100'),
        ('3g','gorra3','Imagenes/Gorras/gorra3.jpg','100'),
        ('4g','gorra4','Imagenes/Gorras/gorra4.jpg','100'),
        ('5g','gorra5','Imagenes/Gorras/gorra5.jpg','100'),
        ('6g','gorra6','Imagenes/Gorras/gorra6.jpg','100'),
        ('7g','gorra7','Imagenes/Gorras/gorra7.jpg','100'),
        ('8g','gorra8','Imagenes/Gorras/gorra8.jpg','100');

INSERT INTO Playera(idPlayera, nombrePlayera, urlPlayera, precioPlayera)
VALUES  ('1p','playera1','Imagenes/Playeras/playera1.jpg','100'),
        ('2p','playera2','Imagenes/Playeras/playera2.jpg','100'),
        ('3p','playera3','Imagenes/Playeras/playera3.jpg','100'),
        ('4p','playera4','Imagenes/Playeras/playera4.jpg','100'),
        ('5p','playera5','Imagenes/Playeras/playera5.jpg','100'),
        ('6p','playera6','Imagenes/Playeras/playera6.jpg','100'),
        ('7p','playera7','Imagenes/Playeras/playera7.jpg','100'),
        ('8p','playera8','Imagenes/Playeras/playera8.jpg','100');

INSERT INTO Sudadera(idSudadera, nombreSudadera, urlSudadera, precioSudadera)
VALUES  ('1s','sudadera1','Imagenes/Sudaderas/sudadera1.jpg','100'),
        ('2s','sudadera2','Imagenes/Sudaderas/sudadera2.jpg','100'),
        ('3s','sudadera3','Imagenes/Sudaderas/sudadera3.jpg','100'),
        ('4s','sudadera4','Imagenes/Sudaderas/sudadera4.jpg','100'),
        ('5s','sudadera5','Imagenes/Sudaderas/sudadera5.jpg','100'),
        ('6s','sudadera6','Imagenes/Sudaderas/sudadera6.jpg','100'),
        ('7s','sudadera7','Imagenes/Sudaderas/sudadera7.jpg','100'),
        ('8s','sudadera8','Imagenes/Sudaderas/sudadera8.jpg','100');