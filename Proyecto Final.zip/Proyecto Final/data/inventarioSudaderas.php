<?php
	header('Content-type: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$connection = connectionToDataBase();

	if ($connection != null)
	{
		$sql = "SELECT * FROM Sudadera";
		$result = mysqli_query($connection, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$results[] = $row;
			}
			echo json_encode($results);
		}
		else
		{
			header("HTTP/1.1 406 User not found");
			die("Wrong credentials provided.");
		}
	}
	else
	{
		header('HTTP/1.1 500 Bad connection to Database'); //establece protocolos de servicio
		die("The server is down, we couldn't establish the DB connection"); //imprime el mensaje y sale del script

	}

?>