<?php
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "pnm_bd";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
		
	
	if ($conn->connect_error)
	{
		header('HTTP/1.1 500 Bad connection to Database');
		die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		$dato = $_POST["dato"];
	
		$sql = "SELECT * FROM Gorra WHERE nombreGorra = '$dato'";
		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$results[] = $row;
			}
			echo json_encode($results);
		}

		$sql = "SELECT * FROM Playera WHERE nombrePlayera = '$dato'";
		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$results[] = $row;
			}
			echo json_encode($results);
		}

		$sql = "SELECT * FROM Sudadera WHERE nombreSudadera = '$dato'";
		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$results[] = $row;
			}
			echo json_encode($results);
		}

	}
?>