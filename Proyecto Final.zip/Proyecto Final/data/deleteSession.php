<?php
	header('Content-type: application/json');

	session_start();
	if(isset($_SESSION["IDuser"]))
	{
		//Destruye las variable especificada
		unset($_SESSION["IDuser"]);
		session_destroy(); //destruye la informacion registrada de una sesion
		echo json_encode(array("successMessage" => "Cerro sesion correctamente"));
	}
	else
	{
		header('HTTP/1.1 406 Session has expired.');
		die("No ha iniciado sesion");
	}
?>