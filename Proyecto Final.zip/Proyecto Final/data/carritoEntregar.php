<?php
	header('Content-type: application/json');
	header('Accept: application/json');
	require_once __DIR__ . '/dataLayer.php';


	$conn = connectionToDataBase();

	if($conn == null)
	{
		header('HTTP/1.1 500 Bad connection to Database'); //establece protocolos de servicio
		die("The server is down, we couldn't establish the DB connection"); //imprime el mensaje y sale del script
	}
	else
	{	
		session_start();
		$IDuser = $_SESSION['IDuser'];
		$IDuser = $IDuser['idUsuario'];

		$IDarticulo = $_POST["IDarticulo"];
		$tipoArticulo = $_POST["tipoArticulo"];
		
		if($_POST["cantidad"] != null)
		{
			$cantidad = $_POST["cantidad"];	
		}
		else
		{
			$cantidad = 1;
		}

		$sql = "INSERT INTO Carrito(idCarrito, tipoArticulo, idArticulo, cantidad)
				VALUES('$IDuser', '$tipoArticulo', '$IDarticulo', '$cantidad')";

		if(mysqli_query($conn, $sql))
		{
			echo json_encode("Articulo agregado a su carrito");
		}
		else
		{
			header('HTTP/1.1 500 Bad connection, something went wrong while saving your data, please try again later');
			die("Error: " . $sql . "\n" . mysqli_error($conn));
		}
	}
?>